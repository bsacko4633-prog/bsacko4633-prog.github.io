Galaxy-Defender/
│── index.html
│── styles.css
└── script.js
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Galaxy Defender</title>

<link rel="stylesheet" href="styles.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.9.0/p5.min.js"></script
/* Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Page */
body {
    background: linear-gradient(to bottom, #020024, #090979, #000000);
    color: white;
    font-family: Arial, Helvetica, sans-serif;
    text-align: center;
    overflow-x: hidden;
}

/* Title */
h1 {
    margin-top: 20px;
    font-size: 3rem;
    color: #FFD700;
}

/* Description */
p {
    margin: 15px auto;
    width: 80%;
    font-size: 18px;
    line-height: 1.6;
}

/* Game container */
#gameCanvas {
    width: 800px;
    margin: 30px auto;
    border: 4px solid #00FFFF;
    border-radius: 15px;
    background: #000;
    box-shadow: 0 0 25px #00FFFF;
}

/* Canvas */
canvas {
    display: block;
    margin: auto;
    border-radius: 12px;
}

/* Controls */
.controls {
    margin-top: 20px;
    font-size: 18px;
}

.controls ul {
    list-style: none;
    padding: 0;
}

.controls li {
    margin: 8px 0;
}

/* Score and lives */
.info {
    display: flex;
    justify-content: center;
    gap: 40px;
    margin: 20px;
    font-size: 22px;
    font-weight: bold;
}

/* Planet facts */
.fact-box {
    width: 80%;
    max-width: 700px;
    margin: 25px auto;
    padding: 15px;
    background: rgba(255,255,255,0.1);
    border: 2px solid #FFD700;
    border-radius: 10px;
    font-size: 18px;
}

/* Buttons */
button {
    margin-top: 20px;
    padding: 12px 24px;
    background: #00BFFF;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 18px;
    cursor: pointer;
    transition: 0.3s;
}

button:hover {
    background: #FFD700;
    color: black;
}

/* Responsive */
@media (max-width: 850px) {
    #gameCanvas {
        width: 95%;
    }

    canvas {
        width: 100% !important;
        height: auto !important;
    }

    h1 {
        font-size: 2rem;
    }

    p {
        font-size: 16px;
    }
}/* Page */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #87CEEB;
    text-align: center;
}

/* Title */
h1 {
    color: #ff6b00;
    margin-top: 20px;
}

/* Description */
p {
    font-size: 18px;
    color: #333;
}

/* Game Area */
#gameCanvas {
    width: 800px;
    margin: 20px auto;
    border: 5px solid #ffcc00;
    border-radius: 15px;
    background: #ffffff;
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}

/* Canvas */
canvas {
    display: block;
    margin: auto;
}

/* Instructions */
.instructions {
    width: 80%;
    margin: 20px auto;
    padding: 15px;
    background: #fff8dc;
    border-radius: 10px;
    border: 2px solid #ffcc00;
}

.instructions h2 {
    color: #ff6b00;
}

.instructions ul {
    list-style: none;
    padding: 0;
}

.instructions li {
    margin: 8px 0;
    font-size: 18px;
}

/* Button */
button {
    padding: 10px 20px;
    background: #ff6b00;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

button:hover {
    background: #ff9500;
}/* Page */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #87CEEB;
    text-align: center;
}

/* Title */
h1 {
    color: #ff6b00;
    margin-top: 20px;
}

/* Description */
p {
    font-size: 18px;
    color: #333;
}

/* Game Area */
#gameCanvas {
    width: 800px;
    margin: 20px auto;
    border: 5px solid #ffcc00;
    border-radius: 15px;
    background: #ffffff;
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}

/* Canvas */
canvas {
    display: block;
    margin: auto;
}

/* Instructions */
.instructions {
    width: 80%;
    margin: 20px auto;
    padding: 15px;
    background: #fff8dc;
    border-radius: 10px;
    border: 2px solid #ffcc00;
}

.instructions h2 {
    color: #ff6b00;
}

.instructions ul {
    list-style: none;
    padding: 0;
}

.instructions li {
    margin: 8px 0;
    font-size: 18px;
}

/* Button */
button {
    padding: 10px 20px;
    background: #ff6b00;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

button:hover {
    background: #ff9500;
}/* Cartoon Style */

body {
    margin: 0;
    padding: 0;
    background: linear-gradient(#6ec6ff, #b3e5fc);
    font-family: "Comic Sans MS", Arial, sans-serif;
    text-align: center;
}

h1 {
    color: #ff6600;
    font-size: 48px;
    text-shadow: 3px 3px #ffd54f;
    margin-top: 20px;
}

p {
    color: #333;
    font-size: 20px;
}

/* Game Container */
#gameCanvas {
    width: 800px;
    margin: 30px auto;
    background: #ffffff;
    border: 8px solid #ffcc00;
    border-radius: 20px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.3);
}

/* Canvas */
canvas {
    display: block;
    margin: auto;
    border-radius: 15px;
}

/* Instructions */
.instructions {
    width: 80%;
    max-width: 700px;
    margin: 20px auto;
    padding: 20px;
    background: #fff8dc;
    border: 4px solid #ffcc00;
    border-radius: 15px;
}

.instructions h2 {
    color: #ff6600;
}

.instructions ul {
    list-style: none;
    padding: 0;
}

.instructions li {
    margin: 10px 0;
    font-size: 18px;
}

/* Buttons */
button {
    background: #ff6600;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 30px;
    font-size: 18px;
    cursor: pointer;
    transition: 0.3s;
}

button:hover {
    background: #ff9900;
    transform: scale(1.05);
}